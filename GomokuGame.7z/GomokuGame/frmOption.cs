using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GomokuGame
{
    public partial class frmOption : Form
    {
        public frmOption()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void cmbKinhNghiem_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rbtClassic_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmOption_Load(object sender, EventArgs e)
        {

        }
    }
}